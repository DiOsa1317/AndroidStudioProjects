package com.example.sql;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.sql.adapter.StudentAdapter;
import com.example.sql.dao.StudentDao;
import com.example.sql.dao.StudentDaoSqLite;
import com.example.sql.model.Student;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
 private EditText etName, etAge, etPhone, etEmail;
 private AppCompatButton btnAdd;
 private StudentDao studentDao;
 private RecyclerView recyclerView;
    private ItemTouchHelper.SimpleCallback simpleItemTouchCallback;
 private final List<Student> students = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //unit();
        studentDao = new StudentDaoSqLite(this);
        students.addAll(studentDao.findAll());

        etName=findViewById(R.id.et_name);
        etAge=findViewById(R.id.et_age);
        etPhone=findViewById(R.id.et_phone);
        etEmail=findViewById(R.id.et_email);

        recyclerView=findViewById(R.id.rv_student);
        StudentAdapter studentAdapter = new StudentAdapter(students, this);
        recyclerView.setAdapter(studentAdapter);

        btnAdd = findViewById(R.id.btn_add);
        btnAdd.setOnClickListener(new View.OnClickListener() {
                                      @Override
                                      public void onClick(View view) {

                                          Student student = new Student(
                                                  etName.getText().toString(),
                                                  Integer.valueOf(etAge.getText().toString()),
                                                  etPhone.getText().toString(),
                                                  etEmail.getText().toString()
                                          );

                                          studentDao.insert(student);
                                          students.clear();
                                          students.addAll(studentDao.findAll());
                                          studentAdapter.notifyDataSetChanged();
                                      }

                                      ;
                                  });

            simpleItemTouchCallback = new ItemTouchHelper.SimpleCallback(
                        0,
                        ItemTouchHelper.LEFT
                ) {

                    @Override
                    public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
                        Toast.makeText(MainActivity.this, "on Move", Toast.LENGTH_SHORT).show();
                        return false;
                    }

                    @Override
                    public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                        int position = viewHolder.getAdapterPosition();
                        Student student = students.get(position);

                        if (direction == ItemTouchHelper.LEFT) {
                            Toast.makeText(MainActivity.this, "Удалено", Toast.LENGTH_SHORT).show();
                            students.remove(viewHolder.getAdapterPosition());
                            studentAdapter.notifyDataSetChanged();

                        }

                    }
                };

                ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleItemTouchCallback);
                itemTouchHelper.attachToRecyclerView(recyclerView);
    }

    public void unit() {
        //students = new ArrayList<>();
        //students= studentDao.findAll();
        //Student student;
        //student = studentDao.
    }
}
