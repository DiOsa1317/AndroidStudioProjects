package com.example.sql.dao;

import static com.example.sql.database.StudentReaderContract.StudentEntry.COLUMN_ID;
import static com.example.sql.database.StudentReaderContract.StudentEntry.TABLE_NAME;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.sql.database.StudentDbOpenHelper;
import com.example.sql.database.StudentReaderContract;
import com.example.sql.model.Student;

import java.util.ArrayList;
import java.util.List;

public class StudentDaoSqLite implements StudentDao {

    private final StudentDbOpenHelper openHelper;

    public StudentDaoSqLite(Context context) {
        this.openHelper = new StudentDbOpenHelper(context);
    }

    @Override
    public long insert(Student student) {
        SQLiteDatabase sqLiteDatabase = openHelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(
                StudentReaderContract.StudentEntry.COLUMN_NAME, student.getName()
        );
        contentValues.put(
                StudentReaderContract.StudentEntry.COLUMN_AGE, student.getAge()
        );
        contentValues.put(
                StudentReaderContract.StudentEntry.COLUMN_PHONE, student.getPhone()
        );
        contentValues.put(
                StudentReaderContract.StudentEntry.COLUMN_EMAIL, student.getEmail()
        );

        long insert = sqLiteDatabase.insert(
                TABLE_NAME,
                null,
                contentValues
        );
        sqLiteDatabase.close();
        Log.i(StudentReaderContract.LOG_TAG, "insert + " + insert);
        return insert;
    }

    @Override
    public List<Student> findAll() {
        SQLiteDatabase sqLiteDatabase = openHelper.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.query(
                TABLE_NAME,
                null,
                null,
                null,
                null,
                null,
                null
        );
        List<Student> studentList = new ArrayList<>();
        if (cursor.moveToFirst()) {
            int id = cursor.getColumnIndex(COLUMN_ID);
            int name =
                    cursor.getColumnIndex(StudentReaderContract.StudentEntry.COLUMN_NAME);
            int age =
                    cursor.getColumnIndex(StudentReaderContract.StudentEntry.COLUMN_AGE);
            int phone =
                    cursor.getColumnIndex(StudentReaderContract.StudentEntry.COLUMN_PHONE);
            int email =
                    cursor.getColumnIndex(StudentReaderContract.StudentEntry.COLUMN_EMAIL);

            do {
                Student student = new Student(
                        cursor.getLong(id),
                        cursor.getString(name),
                        cursor.getInt(age),
                        cursor.getString(phone),
                        cursor.getString(email)
                );
                studentList.add(student);
            } while (cursor.moveToNext());
        }
        cursor.close();
        sqLiteDatabase.close();
        Log.i(StudentReaderContract.LOG_TAG, "In db : \n + " + studentList.toString());
        return studentList;
    }

    @Override
    public Student findById(long id) {
        SQLiteDatabase readableDatabase = openHelper.getReadableDatabase();
        Cursor cursor = readableDatabase.query(
                TABLE_NAME,
                null,
                StudentReaderContract.StudentEntry.COLUMN_ID + " = ?",
                new String[]{String.valueOf(id)},//тюкю забираем одну строчку и вносим в массив то, что вместо вопросика
                null,
                null,
                null
        );
        if (cursor.moveToFirst()) {//установка на первую строчку
            int colunmnIndexName = cursor.getColumnIndex(StudentReaderContract.StudentEntry.COLUMN_NAME);
            int colunmnIndexAge = cursor.getColumnIndex(StudentReaderContract.StudentEntry.COLUMN_AGE);
            int colunmnIndexPhone = cursor.getColumnIndex(StudentReaderContract.StudentEntry.COLUMN_PHONE);
            int colunmnIndexEmail = cursor.getColumnIndex(StudentReaderContract.StudentEntry.COLUMN_EMAIL);

            Student student = new Student(
                    id,
                    cursor.getString(colunmnIndexName),
                    cursor.getInt(colunmnIndexAge),
                    cursor.getString(colunmnIndexPhone),
                    cursor.getString(colunmnIndexEmail)
            );
            cursor.close();
            readableDatabase.close();
            Log.i(StudentReaderContract.LOG_TAG, "Find student + " + student);
            return student;
        }
        cursor.close();
        readableDatabase.close();
        return null;
    }

    @Override
    public int update(long id, Student student) {
        SQLiteDatabase writableDatabase = openHelper.getWritableDatabase();
        int k = 0;
        Cursor cursor = writableDatabase.query(
                TABLE_NAME,
                null,
                COLUMN_ID + " = ?",
                new String[]{String.valueOf(id)},
                null,
                null,
                null
        );
        if (cursor.moveToFirst()) {//установка на первую строчку
            int colunmnIndexName = cursor.getColumnIndex(StudentReaderContract.StudentEntry.COLUMN_NAME);
            int colunmnIndexAge = cursor.getColumnIndex(StudentReaderContract.StudentEntry.COLUMN_AGE);
            int colunmnIndexPhone = cursor.getColumnIndex(StudentReaderContract.StudentEntry.COLUMN_PHONE);
            int colunmnIndexEmail = cursor.getColumnIndex(StudentReaderContract.StudentEntry.COLUMN_EMAIL);
            Student student1 = new Student(
                    id,
                    cursor.getString(colunmnIndexName),
                    cursor.getInt(colunmnIndexAge),
                    cursor.getString(colunmnIndexPhone),
                    cursor.getString(colunmnIndexEmail)
            );
            if (student1.getName() != student.getName()) {
                student1.setName(student.getName());
                k++;
            }
            if (student1.getAge() != student.getAge()) {
                student1.setAge(student.getAge());
                k++;
            }
            if (student1.getPhone() != student.getPhone()) {
                student1.setPhone(student.getPhone());
                k++;
            }
            if (student1.getEmail() != student.getEmail()) {
                student1.setEmail(student.getEmail());
                k++;
            }
            writableDatabase.close();
            cursor.close();
            Log.i(StudentReaderContract.LOG_TAG, "Update student: + " + student1);
        }
            return k;
    }

    @Override
    public int deleteById(int id) {
        SQLiteDatabase writableDatabase = openHelper.getWritableDatabase();
        int delete = writableDatabase.delete(
                StudentReaderContract.StudentEntry.TABLE_NAME,
                StudentReaderContract.StudentEntry.COLUMN_ID + " = ?",
                new String[]{Long.toString(id)});
        writableDatabase.close();
        Log.i(StudentReaderContract.LOG_TAG, "Delete:  " + delete);
        return delete;
    }
}
