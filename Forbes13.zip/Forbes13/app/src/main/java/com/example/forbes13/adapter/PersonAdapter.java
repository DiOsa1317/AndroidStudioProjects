package com.example.forbes13.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.forbes13.R;
import com.example.forbes13.model.Person;

import java.util.List;

public class PersonAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{

    private  final List<Person> people;
    private final LayoutInflater inflater;

    public PersonAdapter(List<Person> people, LayoutInflater inflater) {
        this.people = people;
        this.inflater = inflater;
    }

    private class ViewHolder extends RecyclerView.ViewHolder {
        private final ImageView ivImg;
        private final TextView tvName;
        private final TextView tvMoney;

        public ViewHolder(View itemView) {
            super(itemView);
            ivImg=itemView.findViewById(R.id.flag);
            tvName=itemView.findViewById(R.id.name);
            tvMoney=itemView.findViewById(R.id.money);
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.list_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Person person = people.get(position);
        ((ViewHolder)holder).ivImg.setImageResource(person.getFlag_res());
        ((ViewHolder)holder).tvName.setText(person.getName());
        ((ViewHolder)holder).tvMoney.setText(person.getMoney());
    }

    @Override
    public int getItemCount() {
        return people.size();
    }
}
